// Menu.js

import React from 'react';

const Menu = () => {
  return (
    <div>
      <h1>Menu</h1>
      {/* Add Menu page content here */}
    </div>
  );
}

export default Menu;
